if [ ! -f /data/data/io.neoterm/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/io.neoterm/files/home/.termux/termux.properties ]; then
mkdir -p /data/data/io.neoterm/files/home/.termux
cp /data/data/io.neoterm/files/usr/share/examples/termux/termux.properties /data/data/io.neoterm/files/home/.termux/
fi
